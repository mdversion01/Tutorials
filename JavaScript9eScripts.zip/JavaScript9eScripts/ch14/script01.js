$(document).ready(function() {
	alert("Welcome to jQuery!");
});