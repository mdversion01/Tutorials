$(function() {
	$("#stylemenu").buttonset();
});
