// Read-Me file about "freebie-15.zip"

1. The files:

- freebie-15.psd
- freebie-15.png
- readme.txt (in English)
- lisezmoi.txt (in French)

2. License:

- You can use these resources freely in both personal and commercial projects.
- You can't share these resources when saying that you are the author.
- No attribution are required but it's always appreciated.

3. Problems?

- If you find problems (also about the translations) -> Please, contact-me.
- If you have ideas to improve this freebie -> Please, contact-me.

- And don't forget to show me how you use that.

4. Contact:

- You wanna contact me : MAIL -> hello@launchedpixels.com and TWITTER -> @launchedpixels
- Subscribe to the Newsletter to stay tuned (bottom of website)

ENJOY !

VIA http://www.launchedpixels.com
