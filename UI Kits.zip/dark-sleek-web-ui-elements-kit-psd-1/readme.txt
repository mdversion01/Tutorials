  Pixels Daily
=======================
Name:	Midnight UI Kit
Type:	PSD
Author:	Ali Sher



Notes
=======================
This is a full user interface kit, including a huge number of different elements — video/audio players, buttons, navigation, sliders, and other website elements. These could be very easily arranged into a website layout, and fully developed.



Free Resource Licensing
=======================
All our free resources are licensed under a Creative Commons Attribution license. This license lets you distribute, remix, tweak, and build upon your work, even commercially, as long as you credit Design Curate for the original creation:

http://creativecommons.org/licenses/by/3.0/